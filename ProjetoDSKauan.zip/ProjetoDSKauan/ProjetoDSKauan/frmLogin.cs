﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDSKauan
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            try
            {
                String login;
                MySqlDataReader reg = null;
                MySqlConnection conn = new MySqlConnection("server=localhost; database = bdlanchonete;uid=root;pwd=''");
                MySqlCommand comando = new MySqlCommand();
                comando.Connection = conn;
                comando.CommandText = "SELECT * FROM usuario WHERE login = @login AND Senha = @senha";
                comando.Parameters.AddWithValue("@login", txtLogin.Text);
                comando.Parameters.AddWithValue("@senha", txtSenha.Text);
                conn.Open();
                reg = comando.ExecuteReader();
                if (reg.Read())
                {
                    login = reg["login"].ToString();
                    MessageBox.Show("Acesso permitidol Usuário logado");
                    frmMenu menu = new frmMenu();
                    this.Hide();
                    menu.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Login/Usuário não conferem");
                }

            }
            catch (MySqlException ex)
            {

                MessageBox.Show("erro" + ex.Message);

            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmUsuario user = new frmUsuario();
            user.Show();
            this.Hide();
        }

        private void btnVoltar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmMenu user = new frmMenu();
            user.Show();
            this.Hide();                                                                                                                                                                                                                 
        }
    }
}
