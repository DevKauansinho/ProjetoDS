﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace ProjetoDSKauan
{
    public partial class frmUsuario : Form
    {
        public frmUsuario()
        {
            InitializeComponent();
        }

        private void frmUsuario_Load(object sender, EventArgs e)
        {
            BtnCadastro.Enabled = false;
            txtSenha.Enabled = false;
            txtEmail.Enabled = false;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            BtnCadastro.Enabled = true; 
            txtSenha.Enabled = true;
            txtEmail.Enabled = true;

            txtSenha.Text = "";
            txtEmail.Text = "";


        }

        private void BtnCadastro_Click(object sender, EventArgs e)
        {
               try
               {

                    MySqlConnection conn = new MySqlConnection("server=localhost; database = bdlanchonete;uid=root;pwd=''");
                    MySqlCommand comando = new MySqlCommand();
                    comando.Connection = conn;
                    comando.CommandText = ("insert into usuario (login, senha) values (@login,@senha)");
                    comando.Parameters.AddWithValue("@login", txtEmail.Text);
                    comando.Parameters.AddWithValue("@senha", txtSenha.Text);
                    conn.Open();            
                    comando.ExecuteNonQuery();
                    MessageBox.Show("usuário inserido com sucesso");

               }
               catch (MySqlException ex)
               {

                    MessageBox.Show("erro" + ex.Message);

               }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmLogin user = new frmLogin();
            user.Show();
            this.Hide();
        }

        private void btnVoltar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmMenu user = new frmMenu();
            user.Show();
            this.Hide();
        }
    }
}
